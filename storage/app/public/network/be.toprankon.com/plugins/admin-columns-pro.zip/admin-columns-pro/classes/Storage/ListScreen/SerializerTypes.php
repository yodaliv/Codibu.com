<?php

namespace ACP\Storage\ListScreen;

interface SerializerTypes {

	const PHP = 'php';
	const JSON = 'json';

}